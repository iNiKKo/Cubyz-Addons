v0.0.0
This addon is still work in progress and may malfunction.
Addon made by AustrianWorm for Cubyz 0.15.0-dev.1034+bd97b6618 (should work for most versions though)

current state:

main biomes:
snowy crimsonforest (/tp extrabiomes:snowy_crimsonforest)

sub-biomes:
ice lake
high snowy crimsonforest

blocks:
crimson needles
leafy crimson needles
red fern

items:
pine cone (dropped by crimson Needles)
golden pine cone (can't be obtained yet)
blueberries (can't be obtained yet)

crafting recipies:
4x pine cones -> 1x resin

structures:
different tree structures for snowy crimsonforest
different stone structures for snowy crimsonforest (1/10 chance of having an amber ore in it)
outpost tower structure for snowy crimsonforest (has different verions with different chest loot which is currently not working because of cubyz sbb system)
